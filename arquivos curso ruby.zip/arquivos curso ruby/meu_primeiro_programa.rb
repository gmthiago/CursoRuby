5.times do
  puts 'hello world'
end
