tempo_atual = ARGV.first.to_i

case tempo_atual
  when 0..45
    then puts('first time')
  when 46..90
    then puts('second time')
else
  puts ('are you crazy? that time does not exist in this code')
end
