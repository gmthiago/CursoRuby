nome            = ARGV.first
senha_informada = ARGV[1]

senha_registrada = case nome
                  when 'lucas'   then 's1'
                  when 'thiago'  then 's2'
                   end

autorizado = senha_informada == senha_registrada

if autorizado
    puts 'autorizado'
else
  puts 'nao autorizado'
end
