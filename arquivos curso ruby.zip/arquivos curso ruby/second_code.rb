nome = 'Thiago'

autorizado = nome == 'Pedro'

if !autorizado ### o "!" inverte o valor da variávek
  puts 'n autorizado'
else
  puts 'autorizado'
end
